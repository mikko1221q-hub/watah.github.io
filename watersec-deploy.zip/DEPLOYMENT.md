# WaterSec — Free Deployment Guide

This package is prepared as a static web app for GitHub Pages and Netlify.

## GitHub Pages

1. Create a new GitHub repository, for example `watersec`.
2. Upload **all files in this folder** to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. GitHub will provide a public address similar to:
   `https://YOUR-USERNAME.github.io/watersec/`

No server, database, PHP, or Node.js runtime is required for the mock-data version.

## Netlify

### Option A — Drag and drop

1. Open Netlify and sign in.
2. Go to the Sites area.
3. Drag this deployment folder (or its ZIP contents) into the deployment area.
4. Netlify will publish the site and provide a free `netlify.app` address.

### Option B — Git repository

Push these files to GitHub and import the repository into Netlify. The included `netlify.toml` sets the publish directory to the repository root.

## Important behavior

- Opening the published URL starts at the **Login/Register screen**.
- A successful login always opens the **Dashboard**.
- Logging out returns to **Login**.
- A fresh page load clears the previous browser session and requires login again.
- The application uses browser `localStorage` for mock users/settings; it does not require a backend database.
- `database.sql` is retained as project documentation/reference, but the deployed mock-data app does not execute SQL.

## QR code

After deployment, copy the public site URL into any QR-code generator and use the resulting QR code in the thesis/demo materials.
