-- ============================================================
-- SMART WATER TANK MANAGEMENT SYSTEM
-- Float sensors are the tank decision points. There are no
-- configurable water-level thresholds.
-- ============================================================

DROP DATABASE IF EXISTS smart_water_tank;
CREATE DATABASE smart_water_tank CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE smart_water_tank;

CREATE TABLE users (
    user_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(24) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_active BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE system_settings (
    setting_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    setting_name VARCHAR(64) NOT NULL UNIQUE,
    setting_value VARCHAR(100) NOT NULL,
    unit VARCHAR(30) NULL,
    description VARCHAR(255) NULL,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO system_settings (setting_name, setting_value, unit, description) VALUES
    ('tank_capacity', '750', 'L', 'Default household tank capacity'),
    ('tds_threshold', '500', 'ppm', 'Detection threshold for TDS #1 and TDS #2'),
    ('drain_verification_minutes', '10', 'minutes', 'TDS #2 verification interval while draining'),
    ('refill_lockout_hours', '2', 'hours', 'Lockout after rejected incoming water or completed remediation'),
    ('reading_interval', '60', 'seconds', 'Target sensor reading interval');

CREATE TABLE devices (
    device_id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_name VARCHAR(100) NOT NULL,
    device_uid VARCHAR(100) NOT NULL UNIQUE,
    device_type VARCHAR(50) NOT NULL DEFAULT 'ESP32',
    connection_status ENUM('online','offline') NOT NULL DEFAULT 'offline',
    last_seen_at DATETIME NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

INSERT INTO devices (device_name, device_uid, device_type, connection_status)
VALUES ('AquaGuard ESP32', 'ESP32-DEMO-001', 'ESP32', 'offline');

CREATE TABLE sensor_readings (
    reading_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id INT UNSIGNED NOT NULL,
    water_level_liters DECIMAL(10,2) NULL,
    water_level_percent DECIMAL(5,2) NULL,
    incoming_tds_ppm DECIMAL(10,2) NULL,
    tank_tds_ppm DECIMAL(10,2) NULL,
    upper_float_active BOOLEAN NULL,
    lower_float_active BOOLEAN NULL,
    recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_readings_device FOREIGN KEY (device_id) REFERENCES devices(device_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    INDEX idx_readings_recorded_at (recorded_at),
    INDEX idx_readings_device_time (device_id, recorded_at)
) ENGINE=InnoDB;

CREATE TABLE alerts (
    alert_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    reading_id BIGINT UNSIGNED NULL,
    severity ENUM('info','success','warning','critical') NOT NULL,
    title VARCHAR(150) NOT NULL,
    description TEXT NOT NULL,
    source VARCHAR(100) NOT NULL,
    is_acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    acknowledged_at DATETIME NULL,
    CONSTRAINT fk_alert_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_alert_reading FOREIGN KEY (reading_id) REFERENCES sensor_readings(reading_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_alert_created_at (created_at),
    INDEX idx_alert_severity (severity)
) ENGINE=InnoDB;

CREATE TABLE remediation_events (
    event_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    device_id INT UNSIGNED NOT NULL,
    trigger_reading_id BIGINT UNSIGNED NULL,
    event_type ENUM(
        'tank_tds_high','drain_verification_started','draining_started','draining_completed',
        'incoming_tds_rejected','refilling_started','refilling_completed','high_float_reached',
        'lockout_started','lockout_completed','remediation_completed','manual_override'
    ) NOT NULL,
    reason VARCHAR(255) NULL,
    drain_valve_status ENUM('open','closed') NOT NULL DEFAULT 'closed',
    inlet_valve_status ENUM('open','closed') NOT NULL DEFAULT 'closed',
    buzzer_status ENUM('on','off') NOT NULL DEFAULT 'off',
    started_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at DATETIME NULL,
    CONSTRAINT fk_remediation_device FOREIGN KEY (device_id) REFERENCES devices(device_id)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_remediation_reading FOREIGN KEY (trigger_reading_id) REFERENCES sensor_readings(reading_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_remediation_started_at (started_at)
) ENGINE=InnoDB;

CREATE TABLE activity_logs (
    log_id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    event VARCHAR(150) NOT NULL,
    source VARCHAR(100) NOT NULL,
    status ENUM('normal','warning','critical','active','complete','info') NOT NULL DEFAULT 'normal',
    details TEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_log_user FOREIGN KEY (user_id) REFERENCES users(user_id)
        ON DELETE SET NULL ON UPDATE CASCADE,
    INDEX idx_logs_created_at (created_at)
) ENGINE=InnoDB;

INSERT INTO sensor_readings
    (device_id, water_level_liters, water_level_percent, incoming_tds_ppm, tank_tds_ppm,
     upper_float_active, lower_float_active, recorded_at)
VALUES
    (1, 540.00, 72.00, 240.00, 320.00, FALSE, FALSE, '2026-08-11 08:00:00'),
    (1, 550.00, 73.33, 250.00, 315.00, FALSE, FALSE, '2026-08-11 10:00:00'),
    (1, 545.00, 72.67, 245.00, 330.00, FALSE, FALSE, '2026-08-11 12:00:00'),
    (1, 540.00, 72.00, 240.00, 520.00, FALSE, FALSE, '2026-08-11 13:42:00');

INSERT INTO alerts (reading_id, severity, title, description, source, created_at)
VALUES (4, 'warning', 'High TDS Detected',
        'TDS exceeded the configured system threshold.', 'TDS Sensor #2', '2026-08-11 13:42:00');

INSERT INTO activity_logs (event, source, status, details, created_at) VALUES
    ('System Initialized', 'System', 'normal', 'Water tank monitoring system started successfully.', '2026-08-11 08:00:00'),
    ('TDS Reading Normal', 'TDS Sensor #2', 'normal', 'TDS reading was within the configured threshold.', '2026-08-11 13:40:00'),
    ('High TDS Detected', 'TDS Sensor #2', 'warning', 'TDS exceeded the configured system threshold.', '2026-08-11 13:42:00');

CREATE OR REPLACE VIEW latest_sensor_reading AS
SELECT sr.reading_id, sr.device_id, d.device_name, d.device_uid,
       sr.water_level_liters, sr.water_level_percent, sr.incoming_tds_ppm,
       sr.tank_tds_ppm, sr.upper_float_active, sr.lower_float_active, sr.recorded_at
FROM sensor_readings sr
JOIN devices d ON d.device_id = sr.device_id
WHERE sr.reading_id = (
    SELECT MAX(sr2.reading_id) FROM sensor_readings sr2 WHERE sr2.device_id = sr.device_id
);

CREATE OR REPLACE VIEW active_system_alerts AS
SELECT alert_id, severity, title, description, source, created_at
FROM alerts
WHERE is_acknowledged = FALSE
ORDER BY created_at DESC;
