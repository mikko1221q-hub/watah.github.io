

const MAX_USERS = 5;
const USERS_STORAGE_KEY = "aquaguard_users_v1";
const SESSION_STORAGE_KEY = "aquaguard_session_v1";
const SETTINGS_STORAGE_KEY = "aquaguard_settings_v2";


function loadSavedSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem(SETTINGS_STORAGE_KEY) || "null");
    if (!saved || typeof saved !== "object") return;
    if (Number.isFinite(Number(saved.tankCapacity)) && Number(saved.tankCapacity) > 0) mockData.tankCapacity = Number(saved.tankCapacity);
    if (Number.isFinite(Number(saved.tdsThreshold)) && Number(saved.tdsThreshold) > 0) thresholds.tdsThreshold = Number(saved.tdsThreshold);
    if (Number.isFinite(Number(saved.drainCheckMinutes)) && Number(saved.drainCheckMinutes) > 0) thresholds.drainCheckMinutes = Number(saved.drainCheckMinutes);
    if (Number.isFinite(Number(saved.lockoutHours)) && Number(saved.lockoutHours) > 0) thresholds.lockoutHours = Number(saved.lockoutHours);
    if (typeof saved.alertsEnabled === "boolean") alertsEnabled = saved.alertsEnabled;
    if (typeof saved.buzzerEnabled === "boolean") buzzerEnabled = saved.buzzerEnabled;
  } catch {}
}

function saveSettings() {
  const payload = {
    tankCapacity: mockData.tankCapacity,
    tdsThreshold: thresholds.tdsThreshold,
    drainCheckMinutes: thresholds.drainCheckMinutes,
    lockoutHours: thresholds.lockoutHours,
    alertsEnabled,
    buzzerEnabled,
    savedAt: new Date().toISOString()
  };
  localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(payload));
}

function getUsers() {
  try {
    const users = JSON.parse(localStorage.getItem(USERS_STORAGE_KEY) || "[]");
    return Array.isArray(users) ? users : [];
  } catch {
    return [];
  }
}

function saveUsers(users) {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}

function getCurrentUser() {
  const username = localStorage.getItem(SESSION_STORAGE_KEY);
  return username || null;
}

function setCurrentUser(username) {
  if (username) localStorage.setItem(SESSION_STORAGE_KEY, username);
  else localStorage.removeItem(SESSION_STORAGE_KEY);
}

function normalizeUsername(value) {
  return value.trim().toLowerCase();
}

function showAuthMessage(id, message, success = false) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = message;
  el.classList.toggle("success", success);
}

function updateUserSlotText() {
  const count = getUsers().length;
  setText("userSlotText", `${count} / ${MAX_USERS}`);
  setText("settingsUserCount", `${count} / ${MAX_USERS} users`);
}

function switchAuthMode(mode) {
  const login = mode === "login";
  document.getElementById("loginTab").classList.toggle("active", login);
  document.getElementById("registerTab").classList.toggle("active", !login);
  document.getElementById("loginForm").classList.toggle("hidden", !login);
  document.getElementById("registerForm").classList.toggle("hidden", login);
  showAuthMessage("loginMessage", "");
  showAuthMessage("registerMessage", "");
}

function showAuthScreen(mode = "login") {
  const screen = document.getElementById("authScreen");
  if (screen) screen.classList.remove("hidden");
  switchAuthMode(mode);
  updateUserSlotText();
}

function hideAuthScreen() {
  const screen = document.getElementById("authScreen");
  if (screen) screen.classList.add("hidden");
}

function renderCurrentUser() {
  const username = getCurrentUser();
  setText("currentUserName", username || "User");
}

function handleLogin(event) {
  event.preventDefault();

  const username = normalizeUsername(document.getElementById("loginUsername").value);
  const password = document.getElementById("loginPassword").value;
  const user = getUsers().find(u => u.username === username && u.password === password);

  if (!user) {
    showAuthMessage("loginMessage", "Invalid username or password.");
    return;
  }

  setCurrentUser(user.username);
  document.getElementById("loginForm").reset();
  renderCurrentUser();
  hideAuthScreen();
  addLog("User Login", `User: ${user.username}`, "normal");
  renderAll();
  // Always start every successful login at the Dashboard.
  goToPage("dashboard");
}

function handleRegister(event) {
  event.preventDefault();

  const username = normalizeUsername(document.getElementById("registerUsername").value);
  const password = document.getElementById("registerPassword").value;
  const confirm = document.getElementById("registerConfirmPassword").value;
  const users = getUsers();

  if (users.length >= MAX_USERS) {
    showAuthMessage("registerMessage", "Maximum of 5 users reached. Delete an existing user to free a slot.");
    return;
  }

  if (!/^[a-z0-9._-]{3,24}$/i.test(username)) {
    showAuthMessage("registerMessage", "Username must be 3–24 characters using letters, numbers, dot, underscore, or hyphen.");
    return;
  }

  if (users.some(u => u.username === username)) {
    showAuthMessage("registerMessage", "That username already exists.");
    return;
  }

  if (password.length < 6) {
    showAuthMessage("registerMessage", "Password must be at least 6 characters.");
    return;
  }

  if (password !== confirm) {
    showAuthMessage("registerMessage", "Passwords do not match.");
    return;
  }

  users.push({
    username,
    password,
    createdAt: new Date().toISOString()
  });
  saveUsers(users);

  document.getElementById("registerForm").reset();
  showAuthMessage("registerMessage", "Account created successfully. You can now log in.", true);
  updateUserSlotText();
  setTimeout(() => switchAuthMode("login"), 500);
}

function logout() {
  const username = getCurrentUser();
  if (username) {
    addLog("User Logout", `User: ${username}`, "info");
  }
  setCurrentUser(null);
  renderCurrentUser();
  showAuthScreen("login");
}

function renderUserList() {
  const list = document.getElementById("userList");
  if (!list) return;

  const users = getUsers();
  const current = getCurrentUser();
  list.innerHTML = "";

  if (!users.length) {
    list.innerHTML = '<div class="settings-note">No registered users yet. Create an account to begin.</div>';
    updateUserSlotText();
    return;
  }

  users.forEach(user => {
    const row = document.createElement("div");
    row.className = "user-row";

    const main = document.createElement("div");
    main.className = "user-row-main";

    const avatar = document.createElement("div");
    avatar.className = "user-avatar";
    avatar.textContent = user.username.slice(0, 2).toUpperCase();

    const text = document.createElement("div");
    const name = document.createElement("div");
    name.className = "user-row-name";
    name.textContent = user.username;
    const role = document.createElement("div");
    role.className = "user-row-role";
    role.textContent = user.username === current ? "Current account" : "Registered account";

    text.appendChild(name);
    text.appendChild(role);
    main.appendChild(avatar);
    main.appendChild(text);

    const actions = document.createElement("div");
    actions.className = "user-actions";

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "edit-user-btn";
    editBtn.textContent = "Edit Password";
    editBtn.title = "Update this user's password";
    editBtn.addEventListener("click", () => {
      const nextPassword = window.prompt(`Enter a new password for "${user.username}" (minimum 6 characters):`);
      if (nextPassword === null) return;
      if (nextPassword.length < 6) {
        showQuickUserMessage("Password must be at least 6 characters.");
        return;
      }
      const usersNow = getUsers();
      const target = usersNow.find(u => u.username === user.username);
      if (!target) return;
      target.password = nextPassword;
      target.updatedAt = new Date().toISOString();
      saveUsers(usersNow);
      addLog("Password Updated", `User: ${user.username}`, "normal");
      showQuickUserMessage(`Password updated for "${user.username}". Changes were saved automatically.`, true);
      renderUserList();
    });

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "delete-user-btn";
    deleteBtn.textContent = "Delete User";
    deleteBtn.disabled = user.username === current;
    deleteBtn.title = user.username === current
      ? "Log out before deleting this account."
      : "Delete this account and free a user slot";

    deleteBtn.addEventListener("click", () => {
      if (user.username === getCurrentUser()) return;

      const confirmed = window.confirm(`Delete user "${user.username}"? This will free one user slot.`);
      if (!confirmed) return;

      const remaining = getUsers().filter(u => u.username !== user.username);
      saveUsers(remaining);
      addLog("User Deleted", `User: ${user.username}`, "warning");
      renderUserList();
      updateUserSlotText();
      showQuickUserMessage(`User "${user.username}" deleted. One user slot is now available.`, true);
    });

    actions.appendChild(editBtn);
    actions.appendChild(deleteBtn);
    row.appendChild(main);
    row.appendChild(actions);
    list.appendChild(row);
  });

  updateUserSlotText();
}

function showQuickUserMessage(message, success = false) {
  const el = document.getElementById("quickUserMessage");
  if (!el) return;
  el.textContent = message;
  el.classList.toggle("success", success);
}

function createUserFromSettings(event) {
  event.preventDefault();

  const username = normalizeUsername(document.getElementById("quickUsername").value);
  const password = document.getElementById("quickPassword").value;
  const users = getUsers();

  if (users.length >= MAX_USERS) {
    showQuickUserMessage("Maximum of 5 users reached. Delete an existing user first.");
    return;
  }
  if (!/^[a-z0-9._-]{3,24}$/i.test(username)) {
    showQuickUserMessage("Invalid username format.");
    return;
  }
  if (users.some(u => u.username === username)) {
    showQuickUserMessage("That username already exists.");
    return;
  }
  if (password.length < 6) {
    showQuickUserMessage("Password must be at least 6 characters.");
    return;
  }

  users.push({ username, password, createdAt: new Date().toISOString() });
  saveUsers(users);
  document.getElementById("quickAddUserForm").reset();
  showQuickUserMessage(`User "${username}" created successfully.`, true);
  addLog("User Created", `User: ${username}`, "normal");
  renderUserList();
}

function initializeAuthentication() {
  document.getElementById("loginTab").addEventListener("click", () => switchAuthMode("login"));
  document.getElementById("registerTab").addEventListener("click", () => switchAuthMode("register"));
  document.getElementById("loginForm").addEventListener("submit", handleLogin);
  document.getElementById("registerForm").addEventListener("submit", handleRegister);
  document.getElementById("logoutBtn").addEventListener("click", logout);
  document.getElementById("quickAddUserForm").addEventListener("submit", createUserFromSettings);

  renderCurrentUser();
  renderUserList();

  // Always require a fresh login when the app starts/reloads.
  // The previous authenticated session is intentionally cleared so the
  // application never opens directly on Dashboard after a fresh run.
  setCurrentUser(null);
  const hasUsers = getUsers().length > 0;
  showAuthScreen(hasUsers ? "login" : "register");
  goToPage("dashboard");
}



const DEMO_MINUTE_MS = 1000;
const DEMO_HOUR_MS = 3000;

const mockData = {
  tankCapacity: 750,
  currentWater: 540,
  incomingTds: 240,       // TDS #1 — incoming water
  tankTds: 320,           // TDS #2 — tank water
  esp32Connected: true,
  sensors: {
    incomingTds: "Online",
    tankTds: "Online"
  },
  upperFloat: false,
  lowerFloat: false,
  drainValve: "Closed",
  inletValve: "Closed",
  buzzer: "Off",
  automationState: "monitoring",
  overallStatus: "normal",
  systemMode: "Automatic",
  lockoutUntil: 0,
  lastUpdated: null,
  flowMessage: "Monitoring tank sensors."
};

const thresholds = {
  tdsThreshold: 500,
  drainCheckMinutes: 10,
  lockoutHours: 2
};

let alertsEnabled = true;
let buzzerEnabled = true;

/* ---- Alerts (mock) ---- */
let alertIdCounter = 0;
const alertsData = [
  makeAlert("info", "System Initialized", "Water tank monitoring system started successfully.", "System", "8:00 AM"),
  makeAlert("success", "Monitoring Active", "All sensors reporting normal readings.", "System", "8:01 AM"),
  makeAlert("warning", "High TDS Detected", "TDS exceeded the configured system threshold.", "TDS Sensor", "1:42 PM")
];

/* ---- Activity Logs (mock) ---- */
const activityLog = [
  logEntry("08/11/2026", "8:00 AM", "System Initialized", "System", "normal"),
  logEntry("08/11/2026", "1:40 PM", "TDS Reading Normal", "TDS Sensor", "normal"),
  logEntry("08/11/2026", "1:42 PM", "High TDS Detected", "TDS Sensor", "warning"),
  logEntry("08/11/2026", "1:43 PM", "Drainage Started", "Drain Valve", "active"),
  logEntry("08/11/2026", "1:47 PM", "Refilling Started", "Inlet Valve", "active"),
  logEntry("08/11/2026", "1:55 PM", "Remediation Completed", "System", "complete")
];

/* ---- History (mock time series) ---- */
function generateHistory(points, base, variance, min, max) {
  const arr = [];
  let val = base;
  for (let i = 0; i < points; i++) {
    val += (Math.random() - 0.5) * variance;
    val = Math.max(min, Math.min(max, val));
    arr.push(Math.round(val));
  }
  return arr;
}

const historyData = {
  today: {
    labels: ["8am","10am","12pm","2pm","4pm","6pm","8pm"],
    tds: generateHistory(7, 320, 60, 100, 550),
    level: generateHistory(7, 75, 8, 20, 100)
  },
  "7d": {
    labels: ["Mon","Tue","Wed","Thu","Fri","Sat","Sun"],
    tds: generateHistory(7, 310, 90, 100, 600),
    level: generateHistory(7, 70, 15, 15, 100)
  },
  "30d": {
    labels: Array.from({length: 30}, (_, i) => `${i + 1}`),
    tds: generateHistory(30, 300, 100, 100, 620),
    level: generateHistory(30, 68, 18, 15, 100)
  }
};



function makeAlert(severity, title, desc, source, time) {
  alertIdCounter++;
  return { id: alertIdCounter, severity, title, desc, source, time, date: "08/11/2026" };
}

function logEntry(date, time, event, source, status) {
  return { date, time, event, source, status };
}

function nowTimeString() {
  const d = new Date();
  let h = d.getHours();
  const m = d.getMinutes().toString().padStart(2, "0");
  const ampm = h >= 12 ? "PM" : "AM";
  h = h % 12 || 12;
  return `${h}:${m} ${ampm}`;
}

function severityIcon(sev) {
  return { info: "ℹ", warning: "⚠", critical: "✕", success: "✓" }[sev] || "•";
}

function statusClassFor(value) {
  // maps a semantic status word to a CSS badge class
  const map = {
    normal: "normal", clear: "clear", online: "online", connected: "connected",
    warning: "warning", low: "low",
    critical: "critical", high: "high", offline: "offline", disconnected: "disconnected",
    info: "info", success: "success"
  };
  return map[value.toLowerCase()] || "normal";
}



const navItems = document.querySelectorAll(".nav-item");
const pages = document.querySelectorAll(".page");
const pageSubtitleEl = document.getElementById("pageSubtitle");

const pageSubtitles = {
  dashboard: "Household tank monitoring & automated remediation",
  quality: "Incoming and tank-water TDS monitoring",
  level: "Low and high tank float sensor status",
  alerts: "System-generated notifications and warnings",
  history: "Historical sensor readings",
  logs: "Chronological system event record",
  settings: "Tank, TDS, timer, alert, and system configuration",
  users: "Independent household user account management"
};

function goToPage(pageId) {
  const validPage = [...navItems].some(item => item.dataset.page === pageId) ? pageId : "dashboard";
  navItems.forEach(item => item.classList.toggle("active", item.dataset.page === validPage));
  pages.forEach(p => p.classList.toggle("active", p.id === `page-${validPage}`));
  pageSubtitleEl.textContent = pageSubtitles[validPage] || "";
  closeSidebarMobile();
  if (validPage === "history") drawAllHistoryCharts();
  if (validPage === "users") renderUserList();
}

navItems.forEach(item => {
  item.addEventListener("click", () => goToPage(item.dataset.page));
});

document.querySelectorAll("[data-goto]").forEach(btn => {
  btn.addEventListener("click", () => goToPage(btn.dataset.goto));
});

/* Mobile sidebar toggle */
const sidebar = document.getElementById("sidebar");
const sidebarOverlay = document.getElementById("sidebarOverlay");
const sidebarToggle = document.getElementById("sidebarToggle");

function openSidebarMobile() {
  sidebar.classList.add("open");
  sidebarOverlay.classList.add("visible");
}
function closeSidebarMobile() {
  sidebar.classList.remove("open");
  sidebarOverlay.classList.remove("visible");
}
sidebarToggle && sidebarToggle.addEventListener("click", openSidebarMobile);
sidebarOverlay.addEventListener("click", closeSidebarMobile);



function computeLevelPct() {
  return Math.round((mockData.currentWater / mockData.tankCapacity) * 100);
}

function levelStatus() {
  updateFloatStates();
  if (mockData.upperFloat) return "FULL";
  if (mockData.lowerFloat) return "LOW";
  return "NORMAL";
}

function updateFloatStates() {
  // Mock representation of physical float switches. The switches themselves
  // are the decision points; there are no user-configurable level thresholds.
  const lowFloatPosition = mockData.tankCapacity * 0.15;
  const highFloatPosition = mockData.tankCapacity * 0.95;
  mockData.lowerFloat = mockData.currentWater <= lowFloatPosition;
  mockData.upperFloat = mockData.currentWater >= highFloatPosition;
}

function renderTankAndLevel() {
  const pct = computeLevelPct();
  const status = levelStatus();
  const statusClass = status === "NORMAL" || status === "FULL" ? "normal" : (status === "LOW" ? "warning" : "critical");

  // Tank visual (dashboard + level page share the same water fill elements)
  ["tankWater", "tankWater2"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.height = pct + "%";
  });

  // Big numbers
  setText("tankPercentBig", pct + "%");
  setText("tankPercentBig2", pct + "%");
  setText("tankLitersBig", `${mockData.currentWater} L / ${mockData.tankCapacity} L`);
  setText("tankLitersBig2", `${mockData.currentWater} L / ${mockData.tankCapacity} L`);

  setBadge("tankStatusBadge", status, statusClass);
  setBadge("levelStatusBadge", status, statusClass);
  setBadge("levelStatusBadge2", status, statusClass);

  // Circular progress (dashboard + level page)
  ["levelCircle", "levelCircle2"].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.style.setProperty("--pct", pct);
  });
  setText("levelCirclePct", pct + "%");
  setText("levelCirclePct2", pct + "%");

  setText("levelCurrentL", mockData.currentWater + " L");
  setText("levelCurrentL2", mockData.currentWater + " L");
  setText("levelCapacityL", mockData.tankCapacity + " L");
  setText("levelCapacityL2", mockData.tankCapacity + " L");
  setText("levelPct2", pct + "%");
  updateFloatStates();
  setText("upperFloatState", mockData.upperFloat ? "ACTIVE" : "Inactive");
  setText("lowerFloatState", mockData.lowerFloat ? "ACTIVE" : "Inactive");
}

function tdsStatus(value = mockData.tankTds) {
  if (value > thresholds.tdsThreshold) return "CRITICAL";
  if (value > thresholds.tdsThreshold * 0.8) return "WARNING";
  return "NORMAL";
}

function incomingTdsStatus() {
  return mockData.incomingTds <= thresholds.tdsThreshold ? "ACCEPTABLE" : "REJECT";
}



function renderQuality() {
  const tStatus = tdsStatus();
  const tClass = tStatus === "NORMAL" ? "normal" : (tStatus === "WARNING" ? "warning" : "critical");
  ["tdsValue", "qTdsValue"].forEach(id => setText(id, mockData.tankTds));
  ["tdsStatusBadge", "qTdsStatusBadge"].forEach(id => setBadge(id, tStatus, tClass));

  const inStatus = incomingTdsStatus();
  setText("qIncomingTdsValue", mockData.incomingTds);
  setBadge("qIncomingTdsStatusBadge", inStatus, inStatus === "ACCEPTABLE" ? "normal" : "critical");

  const list = document.getElementById("qualitySummaryList");
  if (list) {
    list.innerHTML = "";
    list.appendChild(statusListItem("TDS #1 · Incoming Water", mockData.incomingTds + " ppm", inStatus === "ACCEPTABLE" ? "normal" : "critical"));
    list.appendChild(statusListItem("TDS #2 · Tank Water", mockData.tankTds + " ppm", tClass));
    list.appendChild(statusListItem("TDS Detection Threshold", thresholds.tdsThreshold + " ppm", "info"));
  }
}

function statusListItem(label, value, cls) {
  const li = document.createElement("li");
  const l = document.createElement("span");
  l.textContent = label;
  const v = document.createElement("span");
  v.className = "status-badge " + cls;
  v.textContent = value;
  li.appendChild(l);
  li.appendChild(v);
  return li;
}



function renderOverallStatus() {
  const card = document.getElementById("overallStatusCard");
  const icon = document.getElementById("overallStatusIcon");
  const title = document.getElementById("overallStatusTitle");
  const desc = document.getElementById("overallStatusDesc");

  card.classList.remove("warning", "critical");

  if (mockData.overallStatus === "critical") {
    card.classList.add("critical");
    icon.textContent = "✕";
    title.textContent = "CONTAMINATION DETECTED";
    desc.textContent = "Sensor readings exceeded the configured system thresholds. Automated remediation has been initiated.";
  } else if (mockData.overallStatus === "warning") {
    card.classList.add("warning");
    icon.textContent = "⚠";
    title.textContent = "WARNING";
    desc.textContent = "One or more readings are approaching the configured system thresholds.";
  } else {
    icon.textContent = "✓";
    title.textContent = "NORMAL";
    desc.textContent = "Water condition is currently within the configured system thresholds.";
  }
}

function renderConnectionAndSystemStatus() {
  const connected = mockData.esp32Connected;
  setText("connText", connected ? "ESP32 Connected" : "ESP32 Disconnected");
  setText("connStateText", connected ? "Connected" : "Disconnected");
  setText("systemModeMini", mockData.systemMode);

  [document.getElementById("connDot"), document.getElementById("connDotLg"), document.getElementById("mobileConnDot")].forEach(el => {
    if (!el) return;
    el.classList.toggle("connected", connected);
    el.classList.toggle("disconnected", !connected);
  });

  // System status list (Dashboard page)
  const list = document.getElementById("systemStatusList");
  if (list) {
    list.innerHTML = "";
    list.appendChild(statusListItem("ESP32", connected ? "Connected" : "Disconnected", connected ? "connected" : "disconnected"));
    list.appendChild(statusListItem("TDS #1 · Incoming", mockData.sensors.incomingTds, mockData.sensors.incomingTds === "Online" ? "online" : "offline"));
    list.appendChild(statusListItem("TDS #2 · Tank", mockData.sensors.tankTds, mockData.sensors.tankTds === "Online" ? "online" : "offline"));
    list.appendChild(statusListItem("Upper Float", mockData.upperFloat ? "Active" : "Inactive", mockData.upperFloat ? "normal" : "info"));
    list.appendChild(statusListItem("Lower Float", mockData.lowerFloat ? "Active" : "Inactive", mockData.lowerFloat ? "warning" : "info"));
    list.appendChild(statusListItem("Drain Solenoid #2", mockData.drainValve, mockData.drainValve === "Open" ? "warning" : "normal"));
    list.appendChild(statusListItem("Inlet Solenoid #1", mockData.inletValve, mockData.inletValve === "Open" ? "warning" : "normal"));
    list.appendChild(statusListItem("2-Hour Lockout", lockoutActive() ? formatLockoutRemaining() : "Inactive", lockoutActive() ? "warning" : "normal"));
    list.appendChild(statusListItem("Automation", automationLabel(mockData.automationState), "info"));
  }
}


const remediationSteps = [
  { key: "monitoring", label: "Monitoring", icon: "✓" },
  { key: "tankTdsHigh", label: "Tank TDS High", icon: "⚠" },
  { key: "drainVerify", label: "10-Min TDS Check", icon: "↻" },
  { key: "draining", label: "Drain Solenoid #2", icon: "↻" },
  { key: "refillCheck", label: "Check Incoming TDS #1", icon: "?" },
  { key: "refilling", label: "Refilling", icon: "↻" },
  { key: "full", label: "High Float Active", icon: "✓" },
  { key: "lockout", label: "2-Hour Lockout", icon: "⌛" },
  { key: "monitoringResumed", label: "Monitoring Resumed", icon: "✓" }
];

function automationLabel(state) {
  const map = {
    monitoring: "Monitoring", tankTdsHigh: "Tank TDS High", drainVerify: "10-Min TDS Check",
    draining: "Draining", refillCheck: "Checking Incoming Water", refilling: "Refilling",
    full: "High Float Active", lockout: "2-Hour Lockout", monitoringResumed: "Monitoring"
  };
  return map[state] || "Monitoring";
}

function currentStepIndex() {
  return remediationSteps.findIndex(s => s.key === mockData.automationState);
}

function renderRemediationStepper() {
  const wrap = document.getElementById("remediationStepper");
  if (!wrap) return;
  wrap.innerHTML = "";
  const activeIdx = currentStepIndex();
  remediationSteps.forEach((step, i) => {
    if (i > 0) {
      const line = document.createElement("div");
      line.className = "rline" + (i <= activeIdx ? " done" : "");
      wrap.appendChild(line);
    }
    const stepEl = document.createElement("div");
    let cls = "rstep";
    if (i < activeIdx) cls += " done";
    else if (i === activeIdx) cls += (step.key === "tankTdsHigh" ? " alert current" : " current");
    stepEl.className = cls;
    stepEl.innerHTML = `<div class="rstep-dot">${i <= activeIdx ? step.icon : i + 1}</div><div class="rstep-label">${step.label}</div>`;
    wrap.appendChild(stepEl);
  });

  const descriptions = {
    monitoring: ["✓ Monitoring", "System reads TDS #1, TDS #2, and the low/high tank float sensors."],
    tankTdsHigh: ["⚠ High Tank TDS", "TDS #2 exceeded the configured threshold. Drain solenoid #2 is being opened."],
    drainVerify: ["↻ 10-Minute Verification", "The tank is draining. After the verification interval, TDS #2 is checked again."],
    draining: ["↻ Continue Draining", "TDS #2 is still high, so draining continues until the tank reading is acceptable."],
    refillCheck: ["? Incoming Water Check", "TDS #1 is checked before inlet solenoid #1 is opened."],
    refilling: ["↻ Refilling", "Incoming TDS is acceptable. The inlet is open until the upper float is active."],
    full: ["✓ High Float Active", "The high tank float is active. Inlet solenoid #1 is closed and monitoring continues."],
    lockout: ["⌛ 2-Hour Lockout", "Incoming water was rejected or a remediation cycle completed. Refill is locked out temporarily."],
    monitoringResumed: ["✓ Monitoring Resumed", "The system has returned to normal sensor monitoring."]
  };
  const [title, desc] = descriptions[mockData.automationState] || descriptions.monitoring;
  const currentBox = document.getElementById("remediationCurrent");
  if (currentBox) currentBox.innerHTML = `<strong>${title}</strong><p>${desc}</p><small>${mockData.flowMessage || ""}</small>`;
}

let remediationTimer = null;
let flowRunId = 0;

function lockoutActive() { return Date.now() < mockData.lockoutUntil; }
function formatLockoutRemaining() {
  const ms = Math.max(0, mockData.lockoutUntil - Date.now());
  const totalSec = Math.ceil(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const sec = totalSec % 60;
  return `${h}h ${m}m ${sec}s`;
}
function setLockout() {
  mockData.lockoutUntil = Date.now() + thresholds.lockoutHours * DEMO_HOUR_MS;
}
function flowDelayMinutes(minutes) { return Math.max(1200, minutes * DEMO_MINUTE_MS); }

function evaluateSystemLogic() {
  updateFloatStates();
  const tdsBad = mockData.tankTds > thresholds.tdsThreshold;
  const idle = ["monitoring", "monitoringResumed", "full"].includes(mockData.automationState);

  if (lockoutActive() && idle) {
    mockData.flowMessage = `Refill lockout active: ${formatLockoutRemaining()} remaining.`;
    mockData.automationState = "lockout";
    mockData.overallStatus = "warning";
    return;
  }
  if (!lockoutActive() && mockData.automationState === "lockout") {
    mockData.automationState = "monitoring";
  }

  if (tdsBad && idle) {
    startTankTdsRemediation();
    return;
  }
  if (mockData.lowerFloat && idle) {
    startRefillSequence();
    return;
  }
  if (mockData.upperFloat && ["monitoring", "full"].includes(mockData.automationState)) {
    mockData.inletValve = "Closed";
    mockData.automationState = "full";
    mockData.overallStatus = "normal";
    mockData.flowMessage = "Upper float active. Inlet solenoid #1 closed.";
    return;
  }
  if (idle) {
    mockData.automationState = "monitoring";
    mockData.overallStatus = tdsStatus() === "WARNING" ? "warning" : "normal";
    mockData.flowMessage = "Monitoring tank sensors.";
  }
}

function startTankTdsRemediation(source = "TDS Sensor #2", alertTitle = "High Tank TDS Detected") {
  const run = ++flowRunId;
  clearTimeout(remediationTimer);
  mockData.overallStatus = "critical";
  mockData.automationState = "tankTdsHigh";
  mockData.flowMessage = "Open Drain Solenoid #2 · start 10-minute verification.";
  addAlert("critical", alertTitle, `${source} exceeded the configured system threshold.`, source);
  addLog(alertTitle, source, "warning");
  renderAll();

  remediationTimer = setTimeout(() => {
    if (run !== flowRunId) return;
    mockData.drainValve = "Open";
    mockData.automationState = "drainVerify";
    mockData.flowMessage = `10-minute verification running. ${thresholds.drainCheckMinutes} minute check is accelerated in mock mode.`;
    addLog("Drain Solenoid #2 Open", "Drain Solenoid #2", "active");
    renderAll();

    remediationTimer = setTimeout(() => {
      if (run !== flowRunId) return;
      // Simulate the affected tank water improving during the drain.
      mockData.tankTds = Math.max(120, Math.round(mockData.tankTds * 0.58));
      if (mockData.tankTds > thresholds.tdsThreshold) {
        mockData.automationState = "draining";
        mockData.flowMessage = "TDS #2 is still high. Continue draining and check again.";
        addLog("TDS #2 Still High", "TDS Sensor #2", "warning");
        renderAll();
        remediationTimer = setTimeout(() => startTankTdsRemediation(source, alertTitle), flowDelayMinutes(thresholds.drainCheckMinutes));
        return;
      }
      mockData.drainValve = "Closed";
      mockData.automationState = "lockout";
      mockData.overallStatus = "normal";
      mockData.flowMessage = "Acceptable TDS reached. Drain solenoid #2 closed. Starting 2-hour lockout.";
      addLog("Acceptable TDS Reached", "TDS Sensor #2", "complete");
      addLog("Drain Solenoid #2 Closed", "Drain Solenoid #2", "complete");
      setLockout();
      addAlert("success", "Tank TDS Normal", "TDS #2 returned to an acceptable reading.", "TDS Sensor #2");
      addLog("2-Hour Lockout Activated", "System", "active");
      renderAll();
      remediationTimer = setTimeout(() => {
        if (run !== flowRunId) return;
        mockData.lockoutUntil = 0;
        mockData.automationState = "monitoringResumed";
        mockData.flowMessage = "Lockout complete. Monitoring resumed.";
        addLog("Lockout Complete", "System", "complete");
        renderAll();
      }, thresholds.lockoutHours * DEMO_HOUR_MS);
    }, flowDelayMinutes(thresholds.drainCheckMinutes));
  }, 900);
}

function startRefillSequence() {
  const run = ++flowRunId;
  clearTimeout(remediationTimer);
  if (lockoutActive()) {
    mockData.automationState = "lockout";
    mockData.flowMessage = `Wait for lockout completion: ${formatLockoutRemaining()}.`;
    renderAll();
    return;
  }

  mockData.automationState = "refillCheck";
  mockData.overallStatus = "warning";
  mockData.flowMessage = "Lower float active. Check 2-hour lockout before refilling.";
  addAlert("warning", "Low Water Level Detected", "Lower float is active. Refill workflow started.", "Lower Float");
  addLog("Low Water Level Detected", "Lower Float", "warning");
  renderAll();

  remediationTimer = setTimeout(() => {
    if (run !== flowRunId) return;
    if (lockoutActive()) {
      mockData.automationState = "lockout";
      mockData.flowMessage = `Wait until lockout completes: ${formatLockoutRemaining()}.`;
      renderAll();
      return;
    }

    mockData.incomingTds = Math.max(100, Math.round(mockData.incomingTds + (Math.random() - 0.5) * 80));
    mockData.automationState = "refillCheck";
    const acceptable = mockData.incomingTds <= thresholds.tdsThreshold;
    if (!acceptable) {
      mockData.inletValve = "Closed";
      mockData.flowMessage = `Incoming TDS #1 is ${mockData.incomingTds} ppm. Reject incoming water and start 2-hour lockout.`;
      addAlert("critical", "High Incoming TDS", "Incoming water was rejected because TDS #1 exceeded the configured threshold.", "TDS Sensor #1");
      addLog("Reject Incoming Water", "TDS Sensor #1", "warning");
      setLockout();
      mockData.automationState = "lockout";
      addLog("2-Hour Lockout Activated", "System", "active");
      renderAll();
      remediationTimer = setTimeout(() => {
        if (run !== flowRunId) return;
        mockData.lockoutUntil = 0;
        mockData.automationState = "monitoringResumed";
        mockData.overallStatus = "normal";
        mockData.flowMessage = "Lockout complete. Monitoring resumed.";
        addLog("Lockout Complete", "System", "complete");
        renderAll();
      }, thresholds.lockoutHours * DEMO_HOUR_MS);
      return;
    }

    mockData.inletValve = "Open";
    mockData.automationState = "refilling";
    mockData.flowMessage = "Incoming TDS acceptable. Open Inlet Solenoid #1 and fill until upper float is active.";
    addLog("Inlet Solenoid #1 Open", "Inlet Solenoid #1", "active");
    addLog("Incoming Water Accepted", "TDS Sensor #1", "complete");
    renderAll();

    const fillTick = () => {
      if (run !== flowRunId) return;
      mockData.currentWater = Math.min(mockData.tankCapacity, mockData.currentWater + Math.round(mockData.tankCapacity * 0.12));
      updateFloatStates();
      if (mockData.upperFloat) {
        mockData.inletValve = "Closed";
        mockData.automationState = "full";
        mockData.overallStatus = "normal";
        mockData.flowMessage = "Upper float active. Close inlet solenoid #1. Full water level reached.";
        addLog("Full Water Level Reached", "Upper Float", "complete");
        addLog("Inlet Solenoid #1 Closed", "Inlet Solenoid #1", "complete");
        renderAll();
      } else {
        renderAll();
        remediationTimer = setTimeout(fillTick, 1800);
      }
    };
    fillTick();
  }, 1200);
}

function addAlert(severity, title, desc, source) {
  if (!alertsEnabled) return;
  const a = makeAlert(severity, title, desc, source, nowTimeString());
  alertsData.unshift(a);
  if (alertsData.length > 40) alertsData.pop();
  renderAlerts();
}

function renderAlerts() {
  const compact = document.getElementById("recentAlertsList");
  const full = document.getElementById("fullAlertsList");
  const navBadge = document.getElementById("alertsNavBadge");

  const recent = alertsData.slice(0, 4);
  if (compact) {
    compact.innerHTML = "";
    if (recent.length === 0) compact.innerHTML = `<p class="metric-note">No alerts recorded yet.</p>`;
    recent.forEach(a => compact.appendChild(renderAlertItem(a)));
  }
  if (full) {
    full.innerHTML = "";
    alertsData.forEach(a => full.appendChild(renderAlertItem(a)));
  }

  const activeCount = alertsData.filter(a => a.severity === "warning" || a.severity === "critical").length;
  if (navBadge) {
    navBadge.textContent = activeCount;
    navBadge.dataset.zero = activeCount === 0 ? "true" : "false";
  }
}

function renderAlertItem(a) {
  const div = document.createElement("div");
  div.className = "alert-item " + a.severity;
  div.innerHTML = `
    <div class="alert-icon">${severityIcon(a.severity)}</div>
    <div class="alert-body">
      <div class="alert-title-row">
        <span class="alert-title">${a.title}</span>
        <span class="status-badge ${statusClassFor(a.severity === "critical" ? "critical" : a.severity)}">${a.severity}</span>
      </div>
      <p class="alert-desc">${a.desc}</p>
      <div class="alert-meta">
        <span>Source: ${a.source}</span>
        <span>${a.date} · ${a.time}</span>
      </div>
    </div>`;
  return div;
}



function addLog(event, source, status) {
  const d = new Date();
  const dateStr = `${(d.getMonth()+1).toString().padStart(2,"0")}/${d.getDate().toString().padStart(2,"0")}/${d.getFullYear()}`;
  activityLog.unshift(logEntry(dateStr, nowTimeString(), event, source, status));
  if (activityLog.length > 60) activityLog.pop();
  renderActivityLogs();
}

function renderActivityLogs() {
  const compact = document.getElementById("recentActivityList");
  const tableBody = document.getElementById("logsTableBody");

  if (compact) {
    compact.innerHTML = "";
    activityLog.slice(0, 5).forEach(e => {
      const row = document.createElement("div");
      row.className = "activity-row";
      row.innerHTML = `<span class="activity-time">${e.time}</span><span class="activity-event">${e.event}</span><span class="activity-source">${e.source}</span>`;
      compact.appendChild(row);
    });
  }

  if (tableBody) {
    tableBody.innerHTML = "";
    activityLog.forEach(e => {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td>${e.date}</td><td>${e.time}</td><td>${e.event}</td><td>${e.source}</td>
        <td><span class="status-badge ${statusClassFor(e.status === "active" || e.status === "complete" ? "info" : e.status)}">${e.status}</span></td>`;
      tableBody.appendChild(tr);
    });
  }
}



function drawLineChart(canvas, labels, series, color) {
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  const dpr = window.devicePixelRatio || 1;
  const cssWidth = canvas.clientWidth || canvas.parentElement.clientWidth;
  const cssHeight = parseInt(canvas.getAttribute("height")) || 110;

  canvas.width = cssWidth * dpr;
  canvas.height = cssHeight * dpr;
  canvas.style.width = cssWidth + "px";
  canvas.style.height = cssHeight + "px";
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, cssWidth, cssHeight);

  const padding = { top: 12, right: 12, bottom: 22, left: 34 };
  const w = cssWidth - padding.left - padding.right;
  const h = cssHeight - padding.top - padding.bottom;

  const max = Math.max(...series) * 1.15 || 1;
  const min = Math.min(0, Math.min(...series));

  // gridlines
  ctx.strokeStyle = "#DCE9F0";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 3; i++) {
    const y = padding.top + (h / 3) * i;
    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(padding.left + w, y);
    ctx.stroke();
  }

  // line
  const stepX = w / (series.length - 1 || 1);
  ctx.beginPath();
  series.forEach((val, i) => {
    const x = padding.left + stepX * i;
    const y = padding.top + h - ((val - min) / (max - min || 1)) * h;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.2;
  ctx.lineJoin = "round";
  ctx.stroke();

  // fill under line
  ctx.lineTo(padding.left + w, padding.top + h);
  ctx.lineTo(padding.left, padding.top + h);
  ctx.closePath();
  ctx.fillStyle = color + "22";
  ctx.fill();

  // points
  ctx.fillStyle = color;
  series.forEach((val, i) => {
    const x = padding.left + stepX * i;
    const y = padding.top + h - ((val - min) / (max - min || 1)) * h;
    ctx.beginPath();
    ctx.arc(x, y, 2.6, 0, Math.PI * 2);
    ctx.fill();
  });


  ctx.fillStyle = "#5C7688";
  ctx.font = "10px IBM Plex Mono, monospace";
  ctx.textAlign = "right";
  ctx.fillText(Math.round(max), padding.left - 6, padding.top + 4);
  ctx.fillText(Math.round(min), padding.left - 6, padding.top + h);


  ctx.textAlign = "center";
  const labelSkip = labels.length > 10 ? Math.ceil(labels.length / 8) : 1;
  labels.forEach((lab, i) => {
    if (i % labelSkip !== 0) return;
    const x = padding.left + stepX * i;
    ctx.fillText(lab, x, cssHeight - 6);
  });
}

let currentHistoryRange = "today";

function drawAllHistoryCharts() {
  const d = historyData[currentHistoryRange];
  drawLineChart(document.getElementById("chartTds"), d.labels, d.tds, "#0891B2");
  drawLineChart(document.getElementById("chartLevel"), d.labels, d.level, "#38BDF8");
}

function drawMiniCharts() {
  const d = historyData.today;
  drawLineChart(document.getElementById("miniChartTds"), d.labels, d.tds, "#0891B2");
  drawLineChart(document.getElementById("miniChartLevel"), d.labels, d.level, "#38BDF8");
}

document.querySelectorAll(".filter-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".filter-btn").forEach(b => b.classList.remove("active"));
    btn.classList.add("active");
    currentHistoryRange = btn.dataset.range;
    drawAllHistoryCharts();
  });
});

window.addEventListener("resize", () => {
  drawMiniCharts();
  if (document.getElementById("page-history").classList.contains("active")) drawAllHistoryCharts();
});


const settingTankCapacity = document.getElementById("settingTankCapacity");
const settingDrainCheckMinutes = document.getElementById("settingDrainCheckMinutes");
const settingLockoutHours = document.getElementById("settingLockoutHours");
const settingTdsThreshold = document.getElementById("settingTdsThreshold");
const toggleAlerts = document.getElementById("toggleAlerts");
const toggleBuzzer = document.getElementById("toggleBuzzer");
const saveSettingsBtn = document.getElementById("saveSettingsBtn");

saveSettingsBtn.addEventListener("click", () => {
  mockData.tankCapacity = parseFloat(settingTankCapacity.value) || 750;
  thresholds.tdsThreshold = parseFloat(settingTdsThreshold.value) || 500;
  thresholds.drainCheckMinutes = parseFloat(settingDrainCheckMinutes.value) || 10;
  thresholds.lockoutHours = parseFloat(settingLockoutHours.value) || 2;
  alertsEnabled = toggleAlerts.checked;
  buzzerEnabled = toggleBuzzer.checked;

  saveSettings();
  addLog("Settings Confirmed and Auto-Saved", "System", "complete");

  saveSettingsBtn.textContent = "Saved ✓";
  saveSettingsBtn.classList.add("saved");
  setTimeout(() => {
    saveSettingsBtn.textContent = "Confirm & Auto Save";
    saveSettingsBtn.classList.remove("saved");
  }, 1600);

  renderAll();
});


function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

function setBadge(id, text, cls) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.className = "status-badge " + cls;
}


function renderAll() {
  mockData.lastUpdated = nowTimeString();
  setText("lastUpdated", mockData.lastUpdated);

  renderOverallStatus();
  renderConnectionAndSystemStatus();
  renderTankAndLevel();
  renderQuality();
  renderRemediationStepper();
  renderAlerts();
  renderActivityLogs();
  drawMiniCharts();
  renderCurrentUser();
  renderUserList();


  if (settingTankCapacity) settingTankCapacity.value = mockData.tankCapacity;
  if (settingTdsThreshold) settingTdsThreshold.value = thresholds.tdsThreshold;
  if (settingDrainCheckMinutes) settingDrainCheckMinutes.value = thresholds.drainCheckMinutes;
  if (settingLockoutHours) settingLockoutHours.value = thresholds.lockoutHours;
  if (toggleAlerts) toggleAlerts.checked = alertsEnabled;
  if (toggleBuzzer) toggleBuzzer.checked = buzzerEnabled;
}


function simulateSensorTick() {
  const idle = ["monitoring", "monitoringResumed", "full"].includes(mockData.automationState);
  if (!idle) {
    if (mockData.automationState === "lockout" && !lockoutActive()) {
      mockData.lockoutUntil = 0;
      mockData.automationState = "monitoringResumed";
      mockData.overallStatus = "normal";
      mockData.flowMessage = "Lockout complete. Monitoring resumed.";
      addLog("Lockout Complete", "System", "complete");
    }
    renderAll();
    return;
  }

  mockData.incomingTds = Math.max(100, Math.round(mockData.incomingTds + (Math.random() - 0.5) * 30));
  mockData.tankTds = Math.max(100, Math.round(mockData.tankTds + (Math.random() - 0.5) * 35));

  if (mockData.automationState === "full") {
    mockData.currentWater = Math.max(0, mockData.currentWater - Math.round(Math.random() * 2));
  } else {
    mockData.currentWater = Math.max(0, mockData.currentWater - Math.round(Math.random() * 4));
  }

  evaluateSystemLogic();
  renderAll();
}

function simulateOccasionalSpike() {
  const idle = ["monitoring", "monitoringResumed", "full"].includes(mockData.automationState);
  if (!idle) return;
  if (Math.random() < 0.22) {
    mockData.tankTds = thresholds.tdsThreshold + Math.round(50 + Math.random() * 150);
    addLog("TDS #2 Spike Simulated", "TDS Sensor #2", "warning");
    evaluateSystemLogic();
    renderAll();
  }
}


document.addEventListener("DOMContentLoaded", () => {
  initializeAuthentication();
  loadSavedSettings();
  renderAll();
  setInterval(simulateSensorTick, 6000);
  setInterval(simulateOccasionalSpike, 45000); 
});
