# MySQL Database Addition

This project includes `database.sql` as the database design for the flowchart-aligned Smart Water Tank Management System.

## Current frontend status

The supplied website is still **frontend-only** and uses JavaScript mock data plus browser `localStorage`. MySQL is not required to run the ZIP.

## Flowchart-aligned database model

The schema now accounts for:

- Maximum 5 user accounts
- Add user, edit/update password, and delete user events
- Automatic-save-ready user/settings records
- TDS #1 for incoming water
- TDS #2 for tank water
- Ultrasonic water-level measurement
- Upper and lower float states
- Drain Solenoid #2 and Inlet Solenoid #1 states
- 10-minute tank-TDS verification interval
- 2-hour refill lockout
- Incoming-water rejection when TDS #1 is above the configured threshold
- Tank-water remediation events and activity logs
- Alerts and historical readings

## Planned architecture

ESP32 + Sensors
        ↓
C# / ASP.NET Core Web API
        ↓
MySQL Database
        ↓
HTML + CSS + JavaScript Web Dashboard

## Install

1. Open MySQL Workbench, phpMyAdmin, or another MySQL client.
2. Open `database.sql`.
3. Execute the entire script.
4. The `smart_water_tank` database will be created.
5. The frontend can still run without MySQL because the current build is mock-data based.

## Thesis development note

The database is a prepared schema for the next C# backend stage. It should not be described as fully integrated until the ASP.NET Core API is connected to MySQL and the ESP32.
